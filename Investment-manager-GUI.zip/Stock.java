public class Stock extends Investment {

    public Stock(String symbol, String name, int quantity, double price, String type) {
        super(symbol, name, quantity, price, type);
    }

}
