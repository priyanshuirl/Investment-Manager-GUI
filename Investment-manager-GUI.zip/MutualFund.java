public class MutualFund extends Investment {

    public MutualFund(String symbol, String name, int quantity, double price, String type) {
        super(symbol, name, quantity, price, type);
    }

}